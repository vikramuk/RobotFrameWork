DAYS = ["Monday", "Wednesday", "Friday", "Sunday"]
details = {'genre':'open-source','type':'test automation', 'pub':2013}