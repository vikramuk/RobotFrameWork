
public class SimpleVariableFile{
	
	/**
	 * Required due to robot framework initialization requirements.
	 * this is essential in presence of non empty constructors only!
	 **/
	public SimpleVariableFile(){
	}

	public static final int CONSTVAL = 12;
	public final String Publisher = "Packt";
	public Integer[] marks = new Integer[]{12, 15, 11, 8, 16};
	public String name = "Robot Framework";

}
